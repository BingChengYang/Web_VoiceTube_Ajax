Practicing web skills by imitating VoiceTube.
