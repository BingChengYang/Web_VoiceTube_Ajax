
function submit_form() {
	document.search_form.submit();
	document.search_form.reset(); 
}